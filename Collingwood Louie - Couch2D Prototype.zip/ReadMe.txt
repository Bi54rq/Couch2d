Player 1- A = Left/D = Right/ Space = Jump
Player 2- Left Arrow = Left/ Right Arrow = Right/ Up Arrow = Jump

https://github.com/Bi54rq/Couch2d